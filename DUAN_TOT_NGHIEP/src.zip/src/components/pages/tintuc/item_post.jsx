
function Item_post() {
  return <>
      <div className="boxTin">
          <div className="boxTin_img">
              <img src="src/publics/image/anhTin1.jpg" alt="anhloi" />
          </div>

          <div className="noiDung">
              <div className="boxTin_tieuDe">
                  <h2>Malaysia truy tố chủ trang web sugar daddy</h2>
              </div>
              <div className="boxTin_noiDung">
                  <div className="p_nd"><a className="text_content" href="/tinTuc/detail">
                      Người sáng lập trang web kết nối đàn ông lớn tuổi với phụ nữ nhỏ tuổi bị buộc tội làm náo loạn dư luận.	</a>
                  </div>
              </div>
          </div>
      </div>
  </>
}

export default Item_post