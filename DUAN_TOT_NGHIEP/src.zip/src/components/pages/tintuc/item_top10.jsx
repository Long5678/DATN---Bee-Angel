
function Item_top10() {
    return <>
        <div className="boxTop10">
            <div className="Text_tinTuc"><a href="">Bộ Ngoại giao đang đàm phán với 15 nước về miễn
                thị thực song phương</a></div>
        </div>
    </>
}

export default Item_top10