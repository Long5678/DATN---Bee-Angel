import Header_auth from "../../layouts/header_auth"
import Footer_auth from "../../layouts/footer_auth"
import "../../../publics/styles/auth.scss"
import Register from "./register"
import { useState } from "react"
import Login from "./login"

function Main_auth() {
    const [check, setCheck] = useState(true)  // state này dùng để check là mình nhấn nút đk hay đk đến render ra cái tab đó
    return <>
        <Header_auth />
        <div className="box-main-auth">
            <div className="box-auth">
                <div className="auth-top">
                    <div className="btn-login-register">
                        <div onClick={() => setCheck(true)} className={`nut ${check ? "active-color" : ""} `}>Đăng ký</div>
                        <div onClick={() => setCheck(false)} className={`nut ${!check ? "active-color" : ""} `}>Đăng Nhập</div>

                    </div>
                    <div className="line-auth"
                        style={{
                            transform: check ? 'translateX(0)' : 'translateX(100%)'
                        }}></div>

                </div>
                <div className="auth-bottom">
                    {check ? <Register /> : <Login />}

                </div>
            </div>
        </div>
        <Footer_auth />
    </>

}

export default Main_auth
