
function Tab_userInfor() {
    return <>
        <section className="tab_userInfor">
            <ul className="ul_tab_userInfor">
                <li className="li_tab_userInfor"><i className="fa-regular fa-user"></i>Hồ sơ của tôi</li>
                <li className="li_tab_userInfor"><i className="fa-solid fa-newspaper"></i>Đơn hàng của tôi </li>
            </ul>
        </section>
    </>
}

export default Tab_userInfor
