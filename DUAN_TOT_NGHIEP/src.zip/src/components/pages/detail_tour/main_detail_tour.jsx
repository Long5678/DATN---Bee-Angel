import Header from "../../layouts/header"
import Detail_tour from "./detail_tour"
import Plane_tour from "./plane_tour"
import Comment_tour from "./comment_tour"
import "../../../publics/styles/detail_tour.scss"

function Main_detail_tour() {
  const planTours = [
    {
      title: "Ngày 1: Khám Phá Cố Đô Huế",
      description: "Bắt Đầu Chuyến Tham Quan Tại Đại Nội, Nơi Lưu Giữ Nhiều Dấu Tích Của Triều Đại Nguyễn. Bạn Có Thể Tham Quan Cửa Ngọ Môn, Điện Thái Hòa, Cung Diên Thọ, Thế Miếu, Và Nhiều Công Trình Khác.",
      ul_lists : [
        "Chùa Thiên Mụ",
        "Thưởng Thức Ẩm Thực Huế",
        "Lăng Tự Đức",
        "Lăng Khải Định",
      ]
    },
    {
      title: "Ngày 2: Khám Phá Các Làng Nghề Và Thắng Cảnh",
      description: "Làng Nón Tây Hồ: Tham Quan Làng Nón Tây Hồ, Nơi Bạn Có Thể Tìm Hiểu Về Quy Trình Làm Nón Lá Truyền Thống Của Người Dân Huế.Làng Thanh Tiên: Thăm Làng Thanh Tiên Nổi Tiếng Với Nghề Làm Hoa Giấy, Một Trong Những Nghề Truyền Thống Có Từ Lâu Đời.",
      ul_lists: [
        "Thưởng Thức Cơm Hến",
        "Đồi Vọng Cảnh",
        "Lăng Minh Mạng",
        "LKhám Phá Ẩm Thực Đường Phố",
      ]
    },
    {
      title: "Ngày 3: Trải Nghiệm Văn Hóa Và Lịch Sử",
      description: "Kết Thúc Chuyến Đi: Quay Trở Lại Thành Phố Để Kết Thúc Hành Trình, Bạn Có Thể Tận Dụng Thời Gia Còn Lại Để Dạo Phố",
      ul_lists: [
        "Thưởng Thức Bún Thịt Nướng",
        "Điện Hòn Chén",
      ]
    },
   
  ]

  return <>
    <Header />
    <div className="boxMain-detail-tour">
      <Detail_tour />
      <Plane_tour planTours={planTours} />
      <Comment_tour />
    </div>
  </>
}

export default Main_detail_tour
