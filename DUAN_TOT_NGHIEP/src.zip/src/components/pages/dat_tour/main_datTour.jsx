import TourForm from "./TourForm"
import TourDetail from "./TourDetail"
import Header from "../../layouts/header"
import Banner from "../home/banner"
function Main_datTour() {
    return <>
        <Header />
        <Banner />
        <div className="main-content">
            <TourForm />
            <TourDetail />
        </div>
    </>
}

export default Main_datTour
