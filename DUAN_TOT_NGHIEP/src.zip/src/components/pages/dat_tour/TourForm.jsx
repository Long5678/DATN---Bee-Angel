import "../../../publics/styles/datTour.scss"
function TourForm() {
    return <>
        <div className="tour-form">
            <h2>Đặt Vé Ngay</h2>
            <form>
                <div className="form-group">
                    <label>Họ và tên</label>
                    <input type="text" placeholder="vui lòng nhập" />
                </div>
                <div className="form-group">
                    <label>Email</label>
                    <input type="email" placeholder="vui lòng nhập" />
                </div>
                <div className="form-group">
                    <label>Số điện thoại</label>
                    <input type="tel" placeholder="vui lòng nhập" />
                </div>
                <div className="form-group">
                    <label>Số lượng du khách</label>
                    <input type="number" placeholder="vui lòng nhập" />
                </div>
                <div className="form-group">
                    <label>Mã giảm giá</label>
                    <input type="text" placeholder="Nếu có" />
                </div>
                <div className="form-group">
                    <label>Đặt xe</label>
                    <input type="text" placeholder="Nếu Muốn" />
                </div>
                <div className="form-group">
                    <label>Ghi chú</label>
                    <textarea placeholder="Không bắt buộc"></textarea>
                </div>
                <div>
                    <input type="checkbox" />
                    <label>Tôi đồng ý điều khoản mà website đưa ra</label>
                </div>
                <button className="btn_thanhToan" type="submit">Thanh toán</button>
            </form>
        </div>
    </>
}

export default TourForm
