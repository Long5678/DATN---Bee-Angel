import "../../../publics/styles/datTour.scss"
import Celander from "./celander"
function TourDetail() {
    return <>
        <div className="div-box-tourDetail-right">
            <div className="tour-details-card">
                <div className="tour-image-details">
                    <img src="https://cdn.media.dulich24.com.vn/diemden/kinh-thanh-hue-5562/kinh-thanh-hue.jpg" alt="Đại Nội Huế" />
                    {/* <FaPlayCircle className="play-icon" /> */}
                </div>
                <div className="tour-info">
                    <div className="tour-header">
                        <div className="tour-rating">
                            <i className="fa-solid fa-star"></i>
                            <span>5.0</span>
                        </div>
                        <div className="tour-location">
                            <i className="fa-solid fa-location-dot"></i>
                            <span>Huế</span>
                        </div>
                    </div>
                    <h3>Đại Nội Huế</h3>
                    <p className="p_tourInfo">
                        Kinh Thành Huế, hoàn thành dưới triều Minh Mạng sau 27 năm xây dựng, là một phần quan trọng của Cố đô Huế.
                    </p>
                    <div className="tour-duration">
                        <label><input type="checkbox" name="duration" value="2N1D" /> 2N1D</label>
                        <label><input type="checkbox" name="duration" value="2N3D" /> 2N3D</label>
                        <label><input type="checkbox" name="duration" value="1 Week" /> 1 Tuần</label>
                    </div>
                    <div className="tour-price-thanhToan">
                        <span className="price-name">Price</span>
                        <span className="price-amount">1.500.000VNĐ</span>
                        {/* <span className="price-currency">VDN</span> */}
                    </div>
                </div>
            </div>

            <Celander />
        </div>
    </>
}

export default TourDetail
