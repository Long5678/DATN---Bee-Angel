import "../../../../publics/styles/list-tour.scss"
import "../../../../publics/styles/sale.scss"
function List_sale() {
  return <>
      <div className="main-list-tour main_list_voucher">
          <div className="box-list-tour">
              <div className="tieuDe-tour">
                  <h2>Voucher</h2>
              </div>
              <div className="line-tour"></div>

             
          </div>
      </div>
  </>
}

export default List_sale
