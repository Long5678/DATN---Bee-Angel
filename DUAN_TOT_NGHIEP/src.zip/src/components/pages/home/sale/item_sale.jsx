
function Item_sale() {
  return <>
  </>
}

export default Item_sale
