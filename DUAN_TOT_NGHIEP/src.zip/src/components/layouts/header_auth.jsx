import "../../publics/styles/header.scss"
function Header_auth() {
  return <>
      <header>
          <div style={{lineHeight: "60px"}} className="main-header">
              <div className="list-menu-header">
                  <ul className="ul-logo">
                      <li>BEE ANGEL</li>

                  </ul>
                  <ul className="list-item-header">
                      {/* <li><a href="/tours">Danh Sách Tour</a></li>
                      <li>Giới Thiệu</li>
                      <li>Tin Tức</li>
                      <li>Điều Khoản</li>
                      <li><button >Đăng ký</button></li>
                      <li><button>Đăng Nhập</button></li> */}
                  </ul>
              </div>
          </div>
      </header>
  </>
}

export default Header_auth
