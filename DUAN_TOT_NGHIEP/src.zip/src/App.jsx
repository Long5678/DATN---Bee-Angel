import './App.css'
import Main_home from './components/pages/home/main_home'

function App() {

  return (
    <>
      <Main_home />
    </>
  )
}

export default App
